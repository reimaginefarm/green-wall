# vaponic.wall

Repo for all vaponic wall code

1. vaponic.collector does power mqtt->influxdb->grafana
